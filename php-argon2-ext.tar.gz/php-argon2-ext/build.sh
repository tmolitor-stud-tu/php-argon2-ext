#!/bin/bash

make clean

cd ext/argon2
CFLAGS="-fPIC" make -j1 OPTTARGET=i686
make test

# Remove the argon2 shared library to force Argon2 to be compiled statically into the extension
rm libargon2.so
cd ../..

# Build the extension
phpize
./configure --with-argon2
make
make install

for d in /etc/php/*/*/conf.d; do echo "extension=argon2.so" >$d/20-argon2.ini; done
